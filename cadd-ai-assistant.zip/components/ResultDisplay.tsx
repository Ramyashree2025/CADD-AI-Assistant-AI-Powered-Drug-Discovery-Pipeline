
import React from 'react';
import type { StepResult } from '../types';

interface ResultDisplayProps {
  result: StepResult;
}

const renderValue = (value: any): JSX.Element => {
    if (typeof value === 'boolean') {
        return <span className={value ? 'text-green-400' : 'text-red-400'}>{value.toString()}</span>;
    }
    if (typeof value === 'number') {
        return <span className="text-cyan-400">{value.toFixed(4)}</span>;
    }
    return <span className="text-content-100">{value}</span>;
};


const renderTable = (data: any[]) => {
    if (!data || data.length === 0) return <p>No data to display.</p>;
    const headers = Object.keys(data[0]);
    return (
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-base-300">
                <thead className="bg-base-300/50">
                    <tr>
                        {headers.map(header => (
                            <th key={header} scope="col" className="px-6 py-3 text-left text-xs font-medium text-content-200 uppercase tracking-wider">{header.replace(/_/g, ' ')}</th>
                        ))}
                    </tr>
                </thead>
                <tbody className="bg-base-200 divide-y divide-base-300">
                    {data.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                            {headers.map(header => (
                                <td key={`${rowIndex}-${header}`} className="px-6 py-4 whitespace-nowrap text-sm font-mono">{renderValue(row[header])}</td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
};

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  const { type, data } = result;

  let content;

  if (type === 'text') {
    content = <p className="text-content-100 whitespace-pre-wrap">{data}</p>;
  } else if (type === 'json') {
    // Check for specific data structures to render as tables
    if (data.triage_results && Array.isArray(data.triage_results)) {
        content = renderTable(data.triage_results);
    } else if (data.docking_scores && Array.isArray(data.docking_scores)) {
        content = renderTable(data.docking_scores);
    } else {
        content = (
          <pre className="bg-base-300 text-content-100 p-4 rounded-md overflow-x-auto text-sm">
            {JSON.stringify(data, null, 2)}
          </pre>
        );
    }
  } else {
    content = <p>Unsupported result format.</p>;
  }

  const explanation = result.explanation || (result.data && result.data.explanation);

  return (
    <div className="mt-6 border-t border-base-300 pt-4">
      <h3 className="text-lg font-semibold text-content-100 mb-2">AI Analysis & Results</h3>
      {explanation && (
        <p className="text-content-200 mb-4 text-sm italic">{explanation}</p>
      )}
      <div className="space-y-4">
        {content}
      </div>
    </div>
  );
};
