
import React from 'react';
import type { PipelineStep, StepId } from '../types';

interface PipelineStepperProps {
  steps: PipelineStep[];
  activeStepId: StepId;
  completedSteps: StepId[];
  onStepClick: (id: StepId) => void;
}

export const PipelineStepper: React.FC<PipelineStepperProps> = ({ steps, activeStepId, completedSteps, onStepClick }) => {
  return (
    <nav className="p-4 bg-base-200 rounded-lg shadow-lg">
      <h2 className="text-lg font-semibold mb-4 text-content-100">Pipeline Stages</h2>
      <ol>
        {steps.map((step, index) => {
          const isCompleted = completedSteps.includes(step.id);
          const isActive = step.id === activeStepId;
          
          let statusClasses = "border-base-300 text-content-200";
          if (isActive) {
            statusClasses = "border-brand-primary text-brand-primary";
          } else if (isCompleted) {
            statusClasses = "border-green-500 text-green-500";
          }
          
          return (
            <li key={step.id} className="relative pb-8">
              {index !== steps.length - 1 && (
                <div className="absolute top-4 left-4 -ml-px mt-0.5 h-full w-0.5 bg-base-300" aria-hidden="true" />
              )}
              <button onClick={() => onStepClick(step.id)} className="group relative flex items-start w-full text-left focus:outline-none">
                <span className="h-9 flex items-center">
                  <span className={`relative z-10 w-8 h-8 flex items-center justify-center rounded-full border-2 bg-base-200 ${statusClasses}`}>
                    {isCompleted && !isActive ? (
                      <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <step.Icon className="w-5 h-5" />
                    )}
                  </span>
                </span>
                <span className="ml-4 min-w-0 flex flex-col">
                  <span className={`text-sm font-semibold tracking-wide ${isActive ? 'text-brand-secondary' : 'text-content-100'}`}>{step.name}</span>
                  <span className="text-xs text-content-200">{step.description}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ol>
    </nav>
  );
};
