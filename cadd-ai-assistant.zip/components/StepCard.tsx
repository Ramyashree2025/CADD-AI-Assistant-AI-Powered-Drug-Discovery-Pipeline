
import React from 'react';
import type { PipelineStep, StepResult } from '../types';
import { Loader } from './Loader';
import { ResultDisplay } from './ResultDisplay';

interface StepCardProps {
  step: PipelineStep;
  onExecute: () => void;
  result: StepResult | null;
  isLoading: boolean;
  error: string | null;
  isSmilesInputVisible: boolean;
  smilesValue: string;
  onSmilesChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  isCompleted: boolean;
}

export const StepCard: React.FC<StepCardProps> = ({
  step,
  onExecute,
  result,
  isLoading,
  error,
  isSmilesInputVisible,
  smilesValue,
  onSmilesChange,
  isCompleted,
}) => {
  const { Icon, name, description } = step;

  const getButtonText = () => {
    if (isLoading) return 'Processing...';
    if (isCompleted) return 'Run Again';
    return `Run ${name}`;
  };

  return (
    <div className="bg-base-200 rounded-lg shadow-2xl p-6 transition-all duration-300">
      <div className="flex items-center space-x-4 mb-4">
        <div className="p-3 bg-base-300 rounded-full">
          <Icon className="w-8 h-8 text-brand-secondary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-content-100">{name}</h2>
          <p className="text-content-200">{description}</p>
        </div>
      </div>

      {isSmilesInputVisible && (
        <div className="mb-6">
          <label htmlFor="smiles-input" className="block text-sm font-medium text-content-100 mb-2">
            Enter Active Molecule (SMILES Format)
          </label>
          <input
            id="smiles-input"
            type="text"
            value={smilesValue}
            onChange={onSmilesChange}
            placeholder="e.g., CC(=O)Oc1ccccc1C(=O)O"
            className="w-full bg-base-300 border border-base-100 rounded-md py-2 px-3 text-content-100 focus:ring-2 focus:ring-brand-primary focus:border-brand-primary"
          />
        </div>
      )}

      <div className="flex justify-end items-center mb-4">
        <button
          onClick={onExecute}
          disabled={isLoading}
          className="flex items-center justify-center bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2 px-4 rounded-md transition duration-300 disabled:bg-base-300 disabled:cursor-not-allowed"
        >
          {isLoading && <Loader />}
          {getButtonText()}
        </button>
      </div>

      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-md mb-4" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      {result && <ResultDisplay result={result} />}
    </div>
  );
};
