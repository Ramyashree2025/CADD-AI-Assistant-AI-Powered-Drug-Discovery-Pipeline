
import { GoogleGenAI, Type } from "@google/genai";
import type { StepId, StepResult } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const parseJsonResponse = (text: string): any => {
    const cleanedText = text.replace(/^```json\s*|```\s*$/g, '').trim();
    try {
        return JSON.parse(cleanedText);
    } catch (e) {
        console.error("Failed to parse JSON:", cleanedText);
        throw new Error("AI returned a malformed JSON response.");
    }
};

const generateContentWithRetry = async (prompt: string, jsonSchema?: any): Promise<StepResult> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: jsonSchema ? {
                responseMimeType: "application/json",
                responseSchema: jsonSchema,
            } : {},
        });
        
        const text = response.text;
        if (jsonSchema) {
            return { type: 'json', data: parseJsonResponse(text) };
        }
        return { type: 'text', data: text };
    } catch (error) {
        console.error("Gemini API Error:", error);
        throw new Error("Failed to get a valid response from the AI model.");
    }
};

export const analyzeDataAssembly = (smiles: string): Promise<StepResult> => {
    const prompt = `Given the active molecule SMILES '${smiles}', simulate the output of a data assembly and featurization step in CADD. Provide a brief explanation. Then, provide a JSON object with a Morgan Fingerprint (as a short bit vector string like '01101...'), Molecular Weight, and LogP.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            features: {
                type: Type.OBJECT,
                properties: {
                    morgan_fingerprint: { type: Type.STRING },
                    molecular_weight: { type: Type.NUMBER },
                    logp: { type: Type.NUMBER },
                },
                required: ["morgan_fingerprint", "molecular_weight", "logp"]
            },
        },
        required: ["explanation", "features"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const detectPocket = (smiles: string): Promise<StepResult> => {
    const prompt = `Simulate the output of a pocket detection tool for a protein target that might bind the molecule '${smiles}'. Provide a brief explanation. Then provide a JSON object with 'center' (x, y, z coordinates) and 'size' (x, y, z dimensions).`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            pocket: {
                type: Type.OBJECT,
                properties: {
                    center: { type: Type.OBJECT, properties: { x: {type: Type.NUMBER}, y: {type: Type.NUMBER}, z: {type: Type.NUMBER} } },
                    size: { type: Type.OBJECT, properties: { x: {type: Type.NUMBER}, y: {type: Type.NUMBER}, z: {type: Type.NUMBER} } },
                },
                required: ["center", "size"]
            }
        },
        required: ["explanation", "pocket"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const generateCandidates = (smiles: string): Promise<StepResult> => {
    const prompt = `You are a de-novo drug design model. Based on the seed molecule SMILES '${smiles}', generate 5 new, structurally similar but distinct molecules. Provide a brief explanation. Then, return a JSON object with a 'generated_smiles' key containing an array of SMILES strings.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            generated_smiles: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["explanation", "generated_smiles"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const triageCandidates = (smilesList: string[]): Promise<StepResult> => {
    const prompt = `For the following SMILES list: ${JSON.stringify(smilesList)}, simulate a rapid triage. For each SMILES, provide a predicted affinity score (pIC50), a QED score, an SA score, and a boolean for Rule-of-Five (Ro5) passage. Provide a brief explanation of the process. Then, return a JSON object containing an array of objects with these properties.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            triage_results: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        smiles: { type: Type.STRING },
                        pIC50: { type: Type.NUMBER },
                        QED: { type: Type.NUMBER },
                        SA_score: { type: Type.NUMBER },
                        Ro5_passed: { type: Type.BOOLEAN },
                    },
                    required: ["smiles", "pIC50", "QED", "SA_score", "Ro5_passed"]
                }
            }
        },
        required: ["explanation", "triage_results"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const runDocking = (smilesList: string[]): Promise<StepResult> => {
    const prompt = `Simulate a docking and AI rescoring process for these top molecules: ${JSON.stringify(smilesList)}. For each, provide a Vina Score, a gnina CNN Score, and a consensus score. Provide a brief explanation. Then return a JSON object containing an array of objects with these properties.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            docking_scores: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        smiles: { type: Type.STRING },
                        vina_score: { type: Type.NUMBER },
                        gnina_cnn_score: { type: Type.NUMBER },
                        consensus_score: { type: Type.NUMBER },
                    },
                     required: ["smiles", "vina_score", "gnina_cnn_score", "consensus_score"]
                }
            }
        },
        required: ["explanation", "docking_scores"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const runMDSimulation = (smiles: string): Promise<StepResult> => {
    const prompt = `Simulate a brief molecular dynamics (MD) report for the molecule '${smiles}'. Mention RMSD stability and provide a simulated MM/GBSA binding free energy (ΔG) value in kcal/mol. Then return a JSON object with this information.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            md_report: {
                type: Type.OBJECT,
                properties: {
                    rmsd_stability: { type: Type.STRING },
                    delta_g: { type: Type.NUMBER },
                },
                required: ["rmsd_stability", "delta_g"]
            }
        },
        required: ["explanation", "md_report"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const predictADMET = (smiles: string): Promise<StepResult> => {
    const prompt = `For the molecule '${smiles}', generate a simulated ADMET prediction report. Include properties like Aqueous Solubility (LogS), BBB Permeability (boolean), hERG Inhibition risk (Low/Medium/High), Ames Mutagenicity (Positive/Negative), and DILI risk (Low/High). Provide a brief explanation. Then return a JSON object.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            admet_properties: {
                type: Type.OBJECT,
                properties: {
                    logS: { type: Type.NUMBER },
                    bbb_permeability: { type: Type.BOOLEAN },
                    herg_inhibition: { type: Type.STRING, enum: ["Low", "Medium", "High"] },
                    ames_mutagenicity: { type: Type.STRING, enum: ["Positive", "Negative"] },
                    dili_risk: { type: Type.STRING, enum: ["Low", "High"] },
                },
                required: ["logS", "bbb_permeability", "herg_inhibition", "ames_mutagenicity", "dili_risk"]
            }
        },
        required: ["explanation", "admet_properties"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const suggestNextSteps = (smiles: string): Promise<StepResult> => {
    const prompt = `Explain the concept of an active learning loop in CADD. Based on the simulated results for molecule '${smiles}', suggest two potential chemical modifications or new molecules to test next, as a Bayesian Optimization model would. Return a JSON object with your explanation and an array of new SMILES strings.`;
    const schema = {
        type: Type.OBJECT,
        properties: {
            explanation: { type: Type.STRING },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["explanation", "suggestions"]
    };
    return generateContentWithRetry(prompt, schema);
};

export const planSynthesis = (smiles: string): Promise<StepResult> => {
    const prompt = `Simulate the output of AiZynthFinder for '${smiles}'. Propose a simple, plausible, 2-step retrosynthesis path. Describe the steps in plain text.`;
    return generateContentWithRetry(prompt);
};

export const generateFinalReport = (initialSmiles: string, finalSmiles: string, allResults: Record<StepId, StepResult | null>): Promise<StepResult> => {
    // A simplified summary for the prompt
    const summary = {
        initial_molecule: initialSmiles,
        final_candidate: finalSmiles,
        docking_score: (allResults['docking-rescoring']?.data as any)?.docking_scores?.[0]?.consensus_score,
        admet_summary: (allResults['admet-prediction']?.data as any)?.admet_properties,
    };
    const prompt = `Summarize the simulated CADD pipeline findings. The initial molecule was '${initialSmiles}' and the final candidate is '${finalSmiles}'. Key results: ${JSON.stringify(summary)}. Write a concise hand-off report highlighting predicted potency, ADMET risks, and synthesis feasibility.`;
    return generateContentWithRetry(prompt);
};
