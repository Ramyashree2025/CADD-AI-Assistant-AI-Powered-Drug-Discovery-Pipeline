
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { PipelineStepper } from './components/PipelineStepper';
import { StepCard } from './components/StepCard';
import { PIPELINE_STEPS } from './constants';
import type { PipelineStep, StepResult, StepId } from './types';
import {
  analyzeDataAssembly,
  detectPocket,
  generateCandidates,
  triageCandidates,
  runDocking,
  runMDSimulation,
  predictADMET,
  suggestNextSteps,
  planSynthesis,
  generateFinalReport,
} from './services/geminiService';

const App: React.FC = () => {
  const [activeStep, setActiveStep] = useState<StepId>('data-assembly');
  const [moleculeSmiles, setMoleculeSmiles] = useState<string>('CCO'); // Default example
  const [results, setResults] = useState<Record<StepId, StepResult | null>>({
    'data-assembly': null,
    'pocket-detection': null,
    'generative-design': null,
    'rapid-triage': null,
    'docking-rescoring': null,
    'md-simulation': null,
    'admet-prediction': null,
    'active-learning': null,
    'synthesis-planning': null,
    'final-report': null,
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleStepExecution = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      let response: StepResult | undefined;
      const currentStepIndex = PIPELINE_STEPS.findIndex(step => step.id === activeStep);

      switch (activeStep) {
        case 'data-assembly':
          response = await analyzeDataAssembly(moleculeSmiles);
          break;
        case 'pocket-detection':
          response = await detectPocket(moleculeSmiles);
          break;
        case 'generative-design':
          response = await generateCandidates(moleculeSmiles);
          break;
        case 'rapid-triage':
          const generatedSmilesResult = results['generative-design'];
          if (generatedSmilesResult?.type === 'json' && generatedSmilesResult.data.generated_smiles) {
            response = await triageCandidates(generatedSmilesResult.data.generated_smiles);
          } else {
            throw new Error('Generated molecules not found. Please complete the "Generative Design" step first.');
          }
          break;
        case 'docking-rescoring':
           const triageResult = results['rapid-triage'];
           if (triageResult?.type === 'json' && Array.isArray(triageResult.data)) {
             const topSmiles = triageResult.data.slice(0, 3).map((item: any) => item.smiles);
             response = await runDocking(topSmiles);
           } else {
             throw new Error('Triage results not found. Please complete the "Rapid Triage" step first.');
           }
          break;
        case 'md-simulation':
           const dockingResult = results['docking-rescoring'];
           if (dockingResult?.type === 'json' && Array.isArray(dockingResult.data) && dockingResult.data.length > 0) {
             const topMolecule = dockingResult.data[0].smiles;
             response = await runMDSimulation(topMolecule);
           } else {
             throw new Error('Docking results not found.');
           }
          break;
        case 'admet-prediction':
           const mdResultSource = results['docking-rescoring'];
            if (mdResultSource?.type === 'json' && Array.isArray(mdResultSource.data) && mdResultSource.data.length > 0) {
              const topMolecule = mdResultSource.data[0].smiles;
              response = await predictADMET(topMolecule);
            } else {
              throw new Error('Docking results not found.');
            }
          break;
        case 'active-learning':
           const admetResultSource = results['docking-rescoring'];
           if (admetResultSource?.type === 'json' && Array.isArray(admetResultSource.data) && admetResultSource.data.length > 0) {
             const topMolecule = admetResultSource.data[0].smiles;
             response = await suggestNextSteps(topMolecule);
           } else {
             throw new Error('Docking results not found.');
           }
          break;
        case 'synthesis-planning':
           const activeLearningSource = results['docking-rescoring'];
           if (activeLearningSource?.type === 'json' && Array.isArray(activeLearningSource.data) && activeLearningSource.data.length > 0) {
             const topMolecule = activeLearningSource.data[0].smiles;
             response = await planSynthesis(topMolecule);
           } else {
             throw new Error('Docking results not found.');
           }
          break;
        case 'final-report':
            const finalCandidateSource = results['docking-rescoring'];
            if (finalCandidateSource?.type === 'json' && Array.isArray(finalCandidateSource.data) && finalCandidateSource.data.length > 0) {
              const finalCandidateSmiles = finalCandidateSource.data[0].smiles;
              response = await generateFinalReport(moleculeSmiles, finalCandidateSmiles, results);
            } else {
              throw new Error('Docking results not found.');
            }
          break;
      }

      if (response) {
        setResults(prev => ({ ...prev, [activeStep]: response }));
        if (currentStepIndex < PIPELINE_STEPS.length - 1) {
          setActiveStep(PIPELINE_STEPS[currentStepIndex + 1].id);
        }
      }
    } catch (e: any) {
      setError(e.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [activeStep, moleculeSmiles, results]);

  const currentStepInfo: PipelineStep | undefined = PIPELINE_STEPS.find(step => step.id === activeStep);

  return (
    <div className="min-h-screen bg-base-100 text-content-100 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <aside className="lg:w-1/3 xl:w-1/4">
            <PipelineStepper 
              steps={PIPELINE_STEPS} 
              activeStepId={activeStep} 
              completedSteps={Object.keys(results).filter(k => results[k as StepId] !== null) as StepId[]}
              onStepClick={(id) => setActiveStep(id)}
            />
          </aside>
          <div className="flex-1">
            {currentStepInfo && (
              <StepCard
                step={currentStepInfo}
                onExecute={handleStepExecution}
                result={results[activeStep]}
                isLoading={isLoading}
                error={error}
                isSmilesInputVisible={activeStep === 'data-assembly'}
                smilesValue={moleculeSmiles}
                onSmilesChange={(e) => setMoleculeSmiles(e.target.value)}
                isCompleted={results[activeStep] !== null}
              />
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
